/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "i2c.h"
#include "spi.h"
#include "usart.h"
#include "gpio.h"
#include "stdio.h"
#include "math.h"
#include "string.h"
#include "LoRa.h"
#include "ADXL345.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define MAX30100_I2C_ADDRESS (0x57 << 1)
#define REG_FIFO_DATA 0x05
#define BUFFER_LENGTH 100
#define VALID_SIGNAL_THRESHOLD 500
#define GPS_BUFFER_SIZE 512
#define RADIUS 6371e3 // Earth's radius in meters
#define FENCE_LAT 17.239431 // Geo-fence center latitude (example: hyderabad)
#define FENCE_LON 78.474821 // Geo-fence center longitude
#define FENCE_RADIUS 2 // Radius in meters (50m for geo-fence)
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
LoRa myLoRa;
uint8_t LoRa_stat=0;
uint32_t ir_buffer[BUFFER_LENGTH];
uint32_t red_buffer[BUFFER_LENGTH];
uint8_t sample_count = 0;
char uart_buffer[200];
float temperature = 0.0;
char accdata_string[50];
char gpsBuffer[GPS_BUFFER_SIZE];
volatile uint8_t rxByte;
double lat, lon;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void calculate_spo2(uint16_t ir_value, uint16_t red_value, float *spo2);
void print_combined_data(float spo2, uint16_t ir_value, uint16_t red_value, char *accdata_string, float temperature, double lat, double lon);
float read_temperature(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
double toRadians(double degree) {
    return degree * M_PI / 180.0;
}

double haversine(double lat1, double lon1, double lat2, double lon2) {
    double dlat = toRadians(lat2 - lat1);
    double dlon = toRadians(lon2 - lon1);
    double a = sin(dlat / 2) * sin(dlat / 2) +
               cos(toRadians(lat1)) * cos(toRadians(lat2)) *
               sin(dlon / 2) * sin(dlon / 2);
    double c = 2 * atan2(sqrt(a), sqrt(1 - a));
    return RADIUS * c; // Distance in meters
}
// Check if the current location is within the geo-fence
void checkGeoFence(double lat, double lon) {
    double distance = haversine(lat, lon, FENCE_LAT, FENCE_LON);
    if (distance <= FENCE_RADIUS) {
        char message[] = "Inside geo-fence\r\n";
        HAL_UART_Transmit(&huart2, (uint8_t *)message, strlen(message), HAL_MAX_DELAY);
    } else {
        char message[] = "Outside geo-fence\r\n";
        HAL_UART_Transmit(&huart2, (uint8_t *)message, strlen(message), HAL_MAX_DELAY);
    }
}
//Parse NMEA GPGGA sentence to extract latitude and longitude
void parseGPGGA(char *nmea) {

    char ns, ew;

    if (sscanf(nmea, "$GPGGA,%*f,%lf,%c,%lf,%c", &lat, &ns, &lon, &ew) == 4) {
        // Convert latitude from ddmm.mmmm to decimal degrees
        int latDegrees = (int)(lat / 100);
        double latMinutes = lat - (latDegrees * 100);
        lat = latDegrees + (latMinutes / 60.0);
        if (ns == 'S') lat = -lat;

        // Convert longitude from dddmm.mmmm to decimal degrees
        int lonDegrees = (int)(lon / 100);
        double lonMinutes = lon - (lonDegrees * 100);
        lon = lonDegrees + (lonMinutes / 60.0);
        if (ew == 'W') lon = -lon;
        char message[100];
        snprintf(message, sizeof(message), "Latitude: %.6f, Longitude: %.6f\r\n", lat, lon);
        HAL_UART_Transmit(&huart2, (uint8_t *)message, strlen(message), HAL_MAX_DELAY);

        checkGeoFence(lat, lon);
    }
}
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    static uint16_t idx = 0;

    if (huart->Instance == USART1) {
    	 //HAL_UART_Transmit(&huart2, &rxByte, 1, HAL_MAX_DELAY); // Debug: Print each received character
        if (rxByte != '\n' && idx < GPS_BUFFER_SIZE - 1) {
            gpsBuffer[idx++] = rxByte;
        } else {
            gpsBuffer[idx] = '\0'; // Null-terminate the string
            idx = 0; // Reset index for the next sentence

            if (strstr(gpsBuffer, "$GPGGA")) {
            	//HAL_UART_Transmit(&huart2, (uint8_t *)"GPGGA Sentence Received\r\n", 26, HAL_MAX_DELAY); // Debug message
                parseGPGGA(gpsBuffer);
            }
        }
        HAL_UART_Receive_IT(&huart1, &rxByte, 1); // Restart reception
    }
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_I2C1_Init();
  MX_I2C2_Init();
  MX_SPI1_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */
  // Start receiving GPS data
      HAL_UART_Receive_IT(&huart1, &rxByte, 1);


    myLoRa = newLoRa();
    myLoRa.CS_port         = NSS_GPIO_Port;
    myLoRa.CS_pin          = NSS_Pin;
    myLoRa.reset_port      = RST_GPIO_Port;
    myLoRa.reset_pin       = RST_Pin;
    myLoRa.DIO0_port       = DIO0_GPIO_Port;
    myLoRa.DIO0_pin        = DIO0_Pin;
    myLoRa.hSPIx           = &hspi1;

    myLoRa.frequency             = 433;             // default = 433 MHz
    myLoRa.spredingFactor        = SF_10;            // default = SF_7
    myLoRa.bandWidth             = BW_250KHz;       // default = BW_125KHz
    myLoRa.crcRate               = CR_4_5;          // default = CR_4_5
    myLoRa.power                 = POWER_20db;      // default = 20db
    myLoRa.overCurrentProtection = 100;             // default = 100 mA
    myLoRa.preamble              = 8;              // default = 8;

        if(LoRa_init(&myLoRa)==LORA_OK){
      	  LoRa_stat=1;
        }

    /* Initialize Accelerometer */
       TT_ADXL_Init();

       uint8_t init_cmds[][2] = {
              {0x06, 0x03},  // Mode: SpO2
              {0x07, 0x27},  // High-res SpO2, 100 Hz sample rate
              {0x09, 0x24},  // LED currents: IR and Red
          };
          for (int i = 0; i < 3; i++) {
              if (HAL_I2C_Master_Transmit(&hi2c2, MAX30100_I2C_ADDRESS, init_cmds[i], 2, HAL_MAX_DELAY) != HAL_OK) {
                  printf("Error initializing MAX30100\r\n");
              }
          }

          float spo2 = 0.0;

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  /* Read Temperature */
	 	  temperature = read_temperature();

	 	        /* Read Acceleration */
	 	        TT_GET_ACCELERATIONS_STRING();

	 	        /* Read SpO2 Data */
	 	        uint8_t fifo_data[4];
	 	        if (HAL_I2C_Mem_Read(&hi2c2, MAX30100_I2C_ADDRESS, REG_FIFO_DATA, 1, fifo_data, 4, HAL_MAX_DELAY) == HAL_OK) {
	 	            uint16_t red_data = (fifo_data[0] << 8) | fifo_data[1];
	 	            uint16_t ir_data = (fifo_data[2] << 8) | fifo_data[3];

	 	            ir_buffer[sample_count] = ir_data;
	 	            red_buffer[sample_count] = red_data;
	 	            sample_count++;

	 	            if (sample_count == BUFFER_LENGTH) {
	 	                if (ir_buffer[0] > VALID_SIGNAL_THRESHOLD && red_buffer[0] > VALID_SIGNAL_THRESHOLD) {
	 	                	calculate_spo2(ir_data, red_data, &spo2);
	 	                } else {
	 	                    spo2 = 0.0;  // Invalid signal
	 	                }
	 	                sample_count = 0;
	 	            }

	 	            /* Print Combined Data */
	 	            print_combined_data(spo2, ir_data, red_data, accdata_string, temperature,lat, lon);
	 	        } else {
	 	            printf("Error reading MAX30100\r\n");
	 	        }

	 	        HAL_Delay(100);  // Delay for stability
	   }

  /* USER CODE END 3 */
}

void calculate_spo2(uint16_t ir_value, uint16_t red_value, float *spo2) {
    float ir_dc = ir_value;  // IR DC component is the raw IR value
    float red_dc = red_value;  // RED DC component is the raw RED value

    /* Simplified AC calculation (using small variations around DC) */
    float ir_ac = fabs(ir_value - ir_dc);
    float red_ac = fabs(red_value - red_dc);

    // Debug: Print DC and AC components
    printf("RED_DC: %.2f, RED_AC: %.2f, IR_DC: %.2f, IR_AC: %.2f\n", red_dc, red_ac, ir_dc, ir_ac);

    // Compute the ratio
    if (ir_ac > 0 && red_ac > 0) {
        float ratio = (red_ac / red_dc) / (ir_ac / ir_dc);
        printf("RATIO: %.2f\n", ratio);

        // SpO2 calculation formula
        *spo2 = 104.0 - (17.0 * ratio);
        if (*spo2 < 80.0) *spo2 = 80.0;  // Clamp values
        if (*spo2 > 100.0) *spo2 = 100.0;
    } else {
        *spo2 = 0.0;  // Invalid signal
        printf("Invalid AC components. SpO2 set to 0.0%%\n");
    }
}

void print_combined_data(float spo2, uint16_t ir_value, uint16_t red_value, char *accdata_string, float temperature, double lat, double lon) {
    if (strlen(accdata_string) == 0) {
        snprintf(accdata_string, sizeof(accdata_string), "N/A");
    }
    snprintf(uart_buffer, sizeof(uart_buffer),
             "SpO2: %.2f%%, IR: %u, RED: %u, Acc: %s, Temp: %.2fC, lat: %.7f, lon: %.7f\r\n",
             spo2, ir_value, red_value, accdata_string, temperature, lat, lon);
    LoRa_transmit(&myLoRa,(uint8_t*)uart_buffer,strlen(uart_buffer),500);
    HAL_UART_Transmit(&huart2, (uint8_t *)uart_buffer, strlen(uart_buffer), HAL_MAX_DELAY);
}

float read_temperature(void) {
    uint32_t adc_sum = 0;
    for (int i = 0; i < 10; i++) {
        HAL_ADC_Start(&hadc1);
        if (HAL_ADC_PollForConversion(&hadc1, HAL_MAX_DELAY) == HAL_OK) {
            adc_sum += HAL_ADC_GetValue(&hadc1);
        }
        HAL_Delay(10);
    }
    uint32_t adc_value = adc_sum / 10;
    return ((adc_value * 3.3f) / 4095.0f) * 100.0f;
}
/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
